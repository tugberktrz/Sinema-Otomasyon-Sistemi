﻿namespace Sinema_Programı
{
    partial class SinemaRezervasyonProjesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SinemaRezervasyonProjesi));
            this.label1 = new System.Windows.Forms.Label();
            this.lblisim = new System.Windows.Forms.Label();
            this.lblsoyisim = new System.Windows.Forms.Label();
            this.textisim = new System.Windows.Forms.TextBox();
            this.txtsoyisim = new System.Windows.Forms.TextBox();
            this.lblsecilenkoltukno = new System.Windows.Forms.Label();
            this.txtkoltukno = new System.Windows.Forms.TextBox();
            this.txtiptalkoltukno = new System.Windows.Forms.TextBox();
            this.lbliptaledilenkoltukno = new System.Windows.Forms.Label();
            this.lblbos = new System.Windows.Forms.Label();
            this.lbletiket1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.koltuk1 = new System.Windows.Forms.Label();
            this.koltuk2 = new System.Windows.Forms.Label();
            this.koltuk3 = new System.Windows.Forms.Label();
            this.koltuk4 = new System.Windows.Forms.Label();
            this.koltuk6 = new System.Windows.Forms.Label();
            this.koltuk7 = new System.Windows.Forms.Label();
            this.koltuk8 = new System.Windows.Forms.Label();
            this.koltuk9 = new System.Windows.Forms.Label();
            this.koltuk10 = new System.Windows.Forms.Label();
            this.koltuk11 = new System.Windows.Forms.Label();
            this.koltuk12 = new System.Windows.Forms.Label();
            this.koltuk13 = new System.Windows.Forms.Label();
            this.koltuk14 = new System.Windows.Forms.Label();
            this.koltuk15 = new System.Windows.Forms.Label();
            this.koltuk16 = new System.Windows.Forms.Label();
            this.koltuk17 = new System.Windows.Forms.Label();
            this.koltuk18 = new System.Windows.Forms.Label();
            this.koltuk20 = new System.Windows.Forms.Label();
            this.koltuk21 = new System.Windows.Forms.Label();
            this.koltuk22 = new System.Windows.Forms.Label();
            this.koltuk23 = new System.Windows.Forms.Label();
            this.koltuk24 = new System.Windows.Forms.Label();
            this.koltuk25 = new System.Windows.Forms.Label();
            this.koltuk26 = new System.Windows.Forms.Label();
            this.koltuk27 = new System.Windows.Forms.Label();
            this.koltuk28 = new System.Windows.Forms.Label();
            this.koltuk29 = new System.Windows.Forms.Label();
            this.koltuk30 = new System.Windows.Forms.Label();
            this.koltuk31 = new System.Windows.Forms.Label();
            this.koltuk32 = new System.Windows.Forms.Label();
            this.koltuk33 = new System.Windows.Forms.Label();
            this.koltuk34 = new System.Windows.Forms.Label();
            this.koltuk35 = new System.Windows.Forms.Label();
            this.koltuk5 = new System.Windows.Forms.Label();
            this.koltuk19 = new System.Windows.Forms.Label();
            this.lbldolu = new System.Windows.Forms.Label();
            this.lblboskoltuksayisi = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnkaydet = new System.Windows.Forms.Button();
            this.btniptalet = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rdkadin = new System.Windows.Forms.RadioButton();
            this.rderkek = new System.Windows.Forms.RadioButton();
            this.cbFilm = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbSeans = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rbOgrenci = new System.Windows.Forms.RadioButton();
            this.rbTam = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(130, 289);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1144, 35);
            this.label1.TabIndex = 38;
            this.label1.Text = "Rezervasyon işlemleri";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblisim
            // 
            this.lblisim.AutoSize = true;
            this.lblisim.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblisim.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lblisim.Location = new System.Drawing.Point(509, 394);
            this.lblisim.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblisim.Name = "lblisim";
            this.lblisim.Size = new System.Drawing.Size(43, 25);
            this.lblisim.TabIndex = 39;
            this.lblisim.Text = "Adı";
            // 
            // lblsoyisim
            // 
            this.lblsoyisim.AutoSize = true;
            this.lblsoyisim.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblsoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblsoyisim.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lblsoyisim.Location = new System.Drawing.Point(480, 423);
            this.lblsoyisim.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsoyisim.Name = "lblsoyisim";
            this.lblsoyisim.Size = new System.Drawing.Size(78, 25);
            this.lblsoyisim.TabIndex = 40;
            this.lblsoyisim.Text = "Soyadı";
            // 
            // textisim
            // 
            this.textisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textisim.Location = new System.Drawing.Point(572, 393);
            this.textisim.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textisim.Multiline = true;
            this.textisim.Name = "textisim";
            this.textisim.Size = new System.Drawing.Size(204, 25);
            this.textisim.TabIndex = 41;
            // 
            // txtsoyisim
            // 
            this.txtsoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtsoyisim.Location = new System.Drawing.Point(572, 425);
            this.txtsoyisim.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtsoyisim.Multiline = true;
            this.txtsoyisim.Name = "txtsoyisim";
            this.txtsoyisim.Size = new System.Drawing.Size(204, 25);
            this.txtsoyisim.TabIndex = 42;
            // 
            // lblsecilenkoltukno
            // 
            this.lblsecilenkoltukno.AutoSize = true;
            this.lblsecilenkoltukno.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblsecilenkoltukno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblsecilenkoltukno.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lblsecilenkoltukno.Location = new System.Drawing.Point(81, 429);
            this.lblsecilenkoltukno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsecilenkoltukno.Name = "lblsecilenkoltukno";
            this.lblsecilenkoltukno.Size = new System.Drawing.Size(143, 24);
            this.lblsecilenkoltukno.TabIndex = 43;
            this.lblsecilenkoltukno.Text = "Koltuk numarası";
            // 
            // txtkoltukno
            // 
            this.txtkoltukno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtkoltukno.Location = new System.Drawing.Point(235, 428);
            this.txtkoltukno.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtkoltukno.Multiline = true;
            this.txtkoltukno.Name = "txtkoltukno";
            this.txtkoltukno.Size = new System.Drawing.Size(204, 25);
            this.txtkoltukno.TabIndex = 44;
            // 
            // txtiptalkoltukno
            // 
            this.txtiptalkoltukno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtiptalkoltukno.Location = new System.Drawing.Point(828, 400);
            this.txtiptalkoltukno.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtiptalkoltukno.Multiline = true;
            this.txtiptalkoltukno.Name = "txtiptalkoltukno";
            this.txtiptalkoltukno.Size = new System.Drawing.Size(204, 25);
            this.txtiptalkoltukno.TabIndex = 48;
            // 
            // lbliptaledilenkoltukno
            // 
            this.lbliptaledilenkoltukno.AutoSize = true;
            this.lbliptaledilenkoltukno.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbliptaledilenkoltukno.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbliptaledilenkoltukno.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lbliptaledilenkoltukno.Location = new System.Drawing.Point(825, 370);
            this.lbliptaledilenkoltukno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbliptaledilenkoltukno.Name = "lbliptaledilenkoltukno";
            this.lbliptaledilenkoltukno.Size = new System.Drawing.Size(345, 18);
            this.lbliptaledilenkoltukno.TabIndex = 47;
            this.lbliptaledilenkoltukno.Text = "İptal etmek istediğiniz koltuk numarası giriniz";
            // 
            // lblbos
            // 
            this.lblbos.BackColor = System.Drawing.Color.FloralWhite;
            this.lblbos.Location = new System.Drawing.Point(1223, 359);
            this.lblbos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblbos.Name = "lblbos";
            this.lblbos.Size = new System.Drawing.Size(146, 42);
            this.lblbos.TabIndex = 49;
            this.lblbos.Text = "Boş";
            this.lblbos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbletiket1
            // 
            this.lbletiket1.AutoSize = true;
            this.lbletiket1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbletiket1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbletiket1.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.lbletiket1.Location = new System.Drawing.Point(192, 333);
            this.lbletiket1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbletiket1.Name = "lbletiket1";
            this.lbletiket1.Size = new System.Drawing.Size(183, 31);
            this.lbletiket1.TabIndex = 51;
            this.lbletiket1.Text = "Kayıt İşlemleri";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label9.Location = new System.Drawing.Point(607, 333);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(239, 31);
            this.label9.TabIndex = 52;
            this.label9.Text = "Rezervasyon İptali";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(1130, 429);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 20);
            this.label10.TabIndex = 53;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(1132, 495);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 20);
            this.label11.TabIndex = 54;
            // 
            // koltuk1
            // 
            this.koltuk1.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk1.Image = ((System.Drawing.Image)(resources.GetObject("koltuk1.Image")));
            this.koltuk1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk1.Location = new System.Drawing.Point(56, 31);
            this.koltuk1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk1.Name = "koltuk1";
            this.koltuk1.Size = new System.Drawing.Size(138, 42);
            this.koltuk1.TabIndex = 55;
            this.koltuk1.Text = "   1.koltuk";
            this.koltuk1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk2
            // 
            this.koltuk2.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk2.Image = ((System.Drawing.Image)(resources.GetObject("koltuk2.Image")));
            this.koltuk2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk2.Location = new System.Drawing.Point(233, 31);
            this.koltuk2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk2.Name = "koltuk2";
            this.koltuk2.Size = new System.Drawing.Size(142, 42);
            this.koltuk2.TabIndex = 56;
            this.koltuk2.Text = "2.koltuk";
            this.koltuk2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk3
            // 
            this.koltuk3.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk3.Image = ((System.Drawing.Image)(resources.GetObject("koltuk3.Image")));
            this.koltuk3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk3.Location = new System.Drawing.Point(423, 31);
            this.koltuk3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk3.Name = "koltuk3";
            this.koltuk3.Size = new System.Drawing.Size(143, 42);
            this.koltuk3.TabIndex = 57;
            this.koltuk3.Text = "3.koltuk";
            this.koltuk3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk4
            // 
            this.koltuk4.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk4.Image = ((System.Drawing.Image)(resources.GetObject("koltuk4.Image")));
            this.koltuk4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk4.Location = new System.Drawing.Point(620, 31);
            this.koltuk4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk4.Name = "koltuk4";
            this.koltuk4.Size = new System.Drawing.Size(144, 42);
            this.koltuk4.TabIndex = 58;
            this.koltuk4.Text = "4.koltuk";
            this.koltuk4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk6
            // 
            this.koltuk6.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk6.Image = ((System.Drawing.Image)(resources.GetObject("koltuk6.Image")));
            this.koltuk6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk6.Location = new System.Drawing.Point(1026, 31);
            this.koltuk6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk6.Name = "koltuk6";
            this.koltuk6.Size = new System.Drawing.Size(145, 42);
            this.koltuk6.TabIndex = 60;
            this.koltuk6.Text = "6.koltuk";
            this.koltuk6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk7
            // 
            this.koltuk7.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk7.Image = ((System.Drawing.Image)(resources.GetObject("koltuk7.Image")));
            this.koltuk7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk7.Location = new System.Drawing.Point(1211, 31);
            this.koltuk7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk7.Name = "koltuk7";
            this.koltuk7.Size = new System.Drawing.Size(131, 42);
            this.koltuk7.TabIndex = 61;
            this.koltuk7.Text = "7.koltuk";
            this.koltuk7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk8
            // 
            this.koltuk8.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk8.Image = ((System.Drawing.Image)(resources.GetObject("koltuk8.Image")));
            this.koltuk8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk8.Location = new System.Drawing.Point(56, 84);
            this.koltuk8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk8.Name = "koltuk8";
            this.koltuk8.Size = new System.Drawing.Size(138, 42);
            this.koltuk8.TabIndex = 62;
            this.koltuk8.Text = "8.koltuk";
            this.koltuk8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk9
            // 
            this.koltuk9.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk9.Image = ((System.Drawing.Image)(resources.GetObject("koltuk9.Image")));
            this.koltuk9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk9.Location = new System.Drawing.Point(233, 84);
            this.koltuk9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk9.Name = "koltuk9";
            this.koltuk9.Size = new System.Drawing.Size(142, 42);
            this.koltuk9.TabIndex = 63;
            this.koltuk9.Text = "9.koltuk";
            this.koltuk9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk10
            // 
            this.koltuk10.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk10.Image = ((System.Drawing.Image)(resources.GetObject("koltuk10.Image")));
            this.koltuk10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk10.Location = new System.Drawing.Point(423, 84);
            this.koltuk10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk10.Name = "koltuk10";
            this.koltuk10.Size = new System.Drawing.Size(143, 42);
            this.koltuk10.TabIndex = 64;
            this.koltuk10.Text = "10.koltuk";
            this.koltuk10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk11
            // 
            this.koltuk11.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk11.Image = ((System.Drawing.Image)(resources.GetObject("koltuk11.Image")));
            this.koltuk11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk11.Location = new System.Drawing.Point(623, 84);
            this.koltuk11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk11.Name = "koltuk11";
            this.koltuk11.Size = new System.Drawing.Size(141, 42);
            this.koltuk11.TabIndex = 65;
            this.koltuk11.Text = "11.koltuk";
            this.koltuk11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk12
            // 
            this.koltuk12.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk12.Image = ((System.Drawing.Image)(resources.GetObject("koltuk12.Image")));
            this.koltuk12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk12.Location = new System.Drawing.Point(828, 84);
            this.koltuk12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk12.Name = "koltuk12";
            this.koltuk12.Size = new System.Drawing.Size(141, 42);
            this.koltuk12.TabIndex = 66;
            this.koltuk12.Text = "12.koltuk";
            this.koltuk12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk13
            // 
            this.koltuk13.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk13.Image = ((System.Drawing.Image)(resources.GetObject("koltuk13.Image")));
            this.koltuk13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk13.Location = new System.Drawing.Point(1029, 84);
            this.koltuk13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk13.Name = "koltuk13";
            this.koltuk13.Size = new System.Drawing.Size(142, 42);
            this.koltuk13.TabIndex = 67;
            this.koltuk13.Text = "13.koltuk";
            this.koltuk13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk14
            // 
            this.koltuk14.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk14.Image = ((System.Drawing.Image)(resources.GetObject("koltuk14.Image")));
            this.koltuk14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk14.Location = new System.Drawing.Point(1211, 84);
            this.koltuk14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk14.Name = "koltuk14";
            this.koltuk14.Size = new System.Drawing.Size(131, 42);
            this.koltuk14.TabIndex = 68;
            this.koltuk14.Text = "14.koltuk";
            this.koltuk14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk15
            // 
            this.koltuk15.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk15.Image = ((System.Drawing.Image)(resources.GetObject("koltuk15.Image")));
            this.koltuk15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk15.Location = new System.Drawing.Point(56, 136);
            this.koltuk15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk15.Name = "koltuk15";
            this.koltuk15.Size = new System.Drawing.Size(138, 42);
            this.koltuk15.TabIndex = 69;
            this.koltuk15.Text = "15.koltuk";
            this.koltuk15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk16
            // 
            this.koltuk16.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk16.Image = ((System.Drawing.Image)(resources.GetObject("koltuk16.Image")));
            this.koltuk16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk16.Location = new System.Drawing.Point(235, 136);
            this.koltuk16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk16.Name = "koltuk16";
            this.koltuk16.Size = new System.Drawing.Size(140, 42);
            this.koltuk16.TabIndex = 70;
            this.koltuk16.Text = "16.koltuk";
            this.koltuk16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk17
            // 
            this.koltuk17.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk17.Image = ((System.Drawing.Image)(resources.GetObject("koltuk17.Image")));
            this.koltuk17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk17.Location = new System.Drawing.Point(423, 136);
            this.koltuk17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk17.Name = "koltuk17";
            this.koltuk17.Size = new System.Drawing.Size(140, 42);
            this.koltuk17.TabIndex = 71;
            this.koltuk17.Text = "17.koltuk";
            this.koltuk17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.koltuk17.Click += new System.EventHandler(this.koltuk17_Click);
            // 
            // koltuk18
            // 
            this.koltuk18.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk18.Image = ((System.Drawing.Image)(resources.GetObject("koltuk18.Image")));
            this.koltuk18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk18.Location = new System.Drawing.Point(620, 136);
            this.koltuk18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk18.Name = "koltuk18";
            this.koltuk18.Size = new System.Drawing.Size(144, 42);
            this.koltuk18.TabIndex = 72;
            this.koltuk18.Text = "18.koltuk";
            this.koltuk18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk20
            // 
            this.koltuk20.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk20.Image = ((System.Drawing.Image)(resources.GetObject("koltuk20.Image")));
            this.koltuk20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk20.Location = new System.Drawing.Point(1029, 136);
            this.koltuk20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk20.Name = "koltuk20";
            this.koltuk20.Size = new System.Drawing.Size(142, 42);
            this.koltuk20.TabIndex = 74;
            this.koltuk20.Text = "20.koltuk";
            this.koltuk20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk21
            // 
            this.koltuk21.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk21.Image = ((System.Drawing.Image)(resources.GetObject("koltuk21.Image")));
            this.koltuk21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk21.Location = new System.Drawing.Point(1211, 136);
            this.koltuk21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk21.Name = "koltuk21";
            this.koltuk21.Size = new System.Drawing.Size(131, 42);
            this.koltuk21.TabIndex = 75;
            this.koltuk21.Text = "21.koltuk";
            this.koltuk21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk22
            // 
            this.koltuk22.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk22.Image = ((System.Drawing.Image)(resources.GetObject("koltuk22.Image")));
            this.koltuk22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk22.Location = new System.Drawing.Point(56, 187);
            this.koltuk22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk22.Name = "koltuk22";
            this.koltuk22.Size = new System.Drawing.Size(138, 42);
            this.koltuk22.TabIndex = 76;
            this.koltuk22.Text = "22.koltuk";
            this.koltuk22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk23
            // 
            this.koltuk23.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk23.Image = ((System.Drawing.Image)(resources.GetObject("koltuk23.Image")));
            this.koltuk23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk23.Location = new System.Drawing.Point(234, 187);
            this.koltuk23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk23.Name = "koltuk23";
            this.koltuk23.Size = new System.Drawing.Size(141, 42);
            this.koltuk23.TabIndex = 77;
            this.koltuk23.Text = "23.koltuk";
            this.koltuk23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk24
            // 
            this.koltuk24.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk24.Image = ((System.Drawing.Image)(resources.GetObject("koltuk24.Image")));
            this.koltuk24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk24.Location = new System.Drawing.Point(426, 187);
            this.koltuk24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk24.Name = "koltuk24";
            this.koltuk24.Size = new System.Drawing.Size(140, 42);
            this.koltuk24.TabIndex = 78;
            this.koltuk24.Text = "24.koltuk";
            this.koltuk24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk25
            // 
            this.koltuk25.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk25.Image = ((System.Drawing.Image)(resources.GetObject("koltuk25.Image")));
            this.koltuk25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk25.Location = new System.Drawing.Point(623, 187);
            this.koltuk25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk25.Name = "koltuk25";
            this.koltuk25.Size = new System.Drawing.Size(141, 42);
            this.koltuk25.TabIndex = 79;
            this.koltuk25.Text = "25.koltuk";
            this.koltuk25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk26
            // 
            this.koltuk26.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk26.Image = ((System.Drawing.Image)(resources.GetObject("koltuk26.Image")));
            this.koltuk26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk26.Location = new System.Drawing.Point(831, 187);
            this.koltuk26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk26.Name = "koltuk26";
            this.koltuk26.Size = new System.Drawing.Size(138, 42);
            this.koltuk26.TabIndex = 80;
            this.koltuk26.Text = "26.koltuk";
            this.koltuk26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk27
            // 
            this.koltuk27.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk27.Image = ((System.Drawing.Image)(resources.GetObject("koltuk27.Image")));
            this.koltuk27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk27.Location = new System.Drawing.Point(1029, 187);
            this.koltuk27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk27.Name = "koltuk27";
            this.koltuk27.Size = new System.Drawing.Size(142, 42);
            this.koltuk27.TabIndex = 81;
            this.koltuk27.Text = "27.koltuk";
            this.koltuk27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk28
            // 
            this.koltuk28.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk28.Image = ((System.Drawing.Image)(resources.GetObject("koltuk28.Image")));
            this.koltuk28.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk28.Location = new System.Drawing.Point(1211, 187);
            this.koltuk28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk28.Name = "koltuk28";
            this.koltuk28.Size = new System.Drawing.Size(131, 42);
            this.koltuk28.TabIndex = 82;
            this.koltuk28.Text = "28.koltuk";
            this.koltuk28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk29
            // 
            this.koltuk29.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk29.Image = ((System.Drawing.Image)(resources.GetObject("koltuk29.Image")));
            this.koltuk29.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk29.Location = new System.Drawing.Point(56, 239);
            this.koltuk29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk29.Name = "koltuk29";
            this.koltuk29.Size = new System.Drawing.Size(138, 42);
            this.koltuk29.TabIndex = 83;
            this.koltuk29.Text = "29.koltuk";
            this.koltuk29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk30
            // 
            this.koltuk30.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk30.Image = ((System.Drawing.Image)(resources.GetObject("koltuk30.Image")));
            this.koltuk30.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk30.Location = new System.Drawing.Point(232, 239);
            this.koltuk30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk30.Name = "koltuk30";
            this.koltuk30.Size = new System.Drawing.Size(143, 42);
            this.koltuk30.TabIndex = 84;
            this.koltuk30.Text = "30.koltuk";
            this.koltuk30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk31
            // 
            this.koltuk31.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk31.Image = ((System.Drawing.Image)(resources.GetObject("koltuk31.Image")));
            this.koltuk31.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk31.Location = new System.Drawing.Point(426, 239);
            this.koltuk31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk31.Name = "koltuk31";
            this.koltuk31.Size = new System.Drawing.Size(140, 42);
            this.koltuk31.TabIndex = 85;
            this.koltuk31.Text = "31.koltuk";
            this.koltuk31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk32
            // 
            this.koltuk32.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk32.Image = ((System.Drawing.Image)(resources.GetObject("koltuk32.Image")));
            this.koltuk32.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk32.Location = new System.Drawing.Point(623, 239);
            this.koltuk32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk32.Name = "koltuk32";
            this.koltuk32.Size = new System.Drawing.Size(141, 42);
            this.koltuk32.TabIndex = 86;
            this.koltuk32.Text = "32.koltuk";
            this.koltuk32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk33
            // 
            this.koltuk33.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk33.Image = ((System.Drawing.Image)(resources.GetObject("koltuk33.Image")));
            this.koltuk33.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk33.Location = new System.Drawing.Point(828, 239);
            this.koltuk33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk33.Name = "koltuk33";
            this.koltuk33.Size = new System.Drawing.Size(141, 42);
            this.koltuk33.TabIndex = 87;
            this.koltuk33.Text = "33.koltuk";
            this.koltuk33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk34
            // 
            this.koltuk34.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk34.Image = ((System.Drawing.Image)(resources.GetObject("koltuk34.Image")));
            this.koltuk34.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk34.Location = new System.Drawing.Point(1029, 239);
            this.koltuk34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk34.Name = "koltuk34";
            this.koltuk34.Size = new System.Drawing.Size(142, 42);
            this.koltuk34.TabIndex = 88;
            this.koltuk34.Text = "34.koltuk";
            this.koltuk34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk35
            // 
            this.koltuk35.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk35.Image = ((System.Drawing.Image)(resources.GetObject("koltuk35.Image")));
            this.koltuk35.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk35.Location = new System.Drawing.Point(1211, 239);
            this.koltuk35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk35.Name = "koltuk35";
            this.koltuk35.Size = new System.Drawing.Size(131, 42);
            this.koltuk35.TabIndex = 89;
            this.koltuk35.Text = "35.koltuk";
            this.koltuk35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk5
            // 
            this.koltuk5.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk5.Image = ((System.Drawing.Image)(resources.GetObject("koltuk5.Image")));
            this.koltuk5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk5.Location = new System.Drawing.Point(825, 31);
            this.koltuk5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk5.Name = "koltuk5";
            this.koltuk5.Size = new System.Drawing.Size(144, 42);
            this.koltuk5.TabIndex = 59;
            this.koltuk5.Text = "5.koltuk";
            this.koltuk5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // koltuk19
            // 
            this.koltuk19.BackColor = System.Drawing.Color.FloralWhite;
            this.koltuk19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.koltuk19.Image = ((System.Drawing.Image)(resources.GetObject("koltuk19.Image")));
            this.koltuk19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.koltuk19.Location = new System.Drawing.Point(828, 136);
            this.koltuk19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.koltuk19.Name = "koltuk19";
            this.koltuk19.Size = new System.Drawing.Size(141, 42);
            this.koltuk19.TabIndex = 73;
            this.koltuk19.Text = "19.koltuk";
            this.koltuk19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbldolu
            // 
            this.lbldolu.BackColor = System.Drawing.Color.GreenYellow;
            this.lbldolu.Location = new System.Drawing.Point(1223, 453);
            this.lbldolu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldolu.Name = "lbldolu";
            this.lbldolu.Size = new System.Drawing.Size(146, 42);
            this.lbldolu.TabIndex = 50;
            this.lbldolu.Text = "Dolu";
            this.lbldolu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblboskoltuksayisi
            // 
            this.lblboskoltuksayisi.AutoSize = true;
            this.lblboskoltuksayisi.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblboskoltuksayisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblboskoltuksayisi.Location = new System.Drawing.Point(1195, 333);
            this.lblboskoltuksayisi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblboskoltuksayisi.Name = "lblboskoltuksayisi";
            this.lblboskoltuksayisi.Size = new System.Drawing.Size(151, 24);
            this.lblboskoltuksayisi.TabIndex = 93;
            this.lblboskoltuksayisi.Text = "Boş Koltuk Sayısı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(1196, 429);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 24);
            this.label3.TabIndex = 94;
            this.label3.Text = "Dolu Koltuk Sayısı";
            // 
            // btnkaydet
            // 
            this.btnkaydet.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnkaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnkaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnkaydet.Image = ((System.Drawing.Image)(resources.GetObject("btnkaydet.Image")));
            this.btnkaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnkaydet.Location = new System.Drawing.Point(381, 573);
            this.btnkaydet.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnkaydet.Name = "btnkaydet";
            this.btnkaydet.Size = new System.Drawing.Size(182, 36);
            this.btnkaydet.TabIndex = 95;
            this.btnkaydet.Text = "Bilet Kes";
            this.btnkaydet.UseVisualStyleBackColor = false;
            this.btnkaydet.Click += new System.EventHandler(this.btnkaydet_Click);
            // 
            // btniptalet
            // 
            this.btniptalet.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btniptalet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btniptalet.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btniptalet.Image = ((System.Drawing.Image)(resources.GetObject("btniptalet.Image")));
            this.btniptalet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btniptalet.Location = new System.Drawing.Point(828, 444);
            this.btniptalet.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btniptalet.Name = "btniptalet";
            this.btniptalet.Size = new System.Drawing.Size(204, 36);
            this.btniptalet.TabIndex = 96;
            this.btniptalet.Text = "İptal Et";
            this.btniptalet.UseVisualStyleBackColor = false;
            this.btniptalet.Click += new System.EventHandler(this.btniptalet_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(144, 333);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.TabIndex = 98;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label2.Location = new System.Drawing.Point(477, 462);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 25);
            this.label2.TabIndex = 100;
            this.label2.Text = "Cinsiyet";
            // 
            // rdkadin
            // 
            this.rdkadin.AutoSize = true;
            this.rdkadin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rdkadin.Location = new System.Drawing.Point(128, 9);
            this.rdkadin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdkadin.Name = "rdkadin";
            this.rdkadin.Size = new System.Drawing.Size(68, 22);
            this.rdkadin.TabIndex = 107;
            this.rdkadin.TabStop = true;
            this.rdkadin.Text = "Kadın";
            this.rdkadin.UseVisualStyleBackColor = true;
            // 
            // rderkek
            // 
            this.rderkek.AutoSize = true;
            this.rderkek.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rderkek.Location = new System.Drawing.Point(13, 9);
            this.rderkek.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rderkek.Name = "rderkek";
            this.rderkek.Size = new System.Drawing.Size(70, 22);
            this.rderkek.TabIndex = 106;
            this.rderkek.TabStop = true;
            this.rderkek.Text = "Erkek";
            this.rderkek.UseVisualStyleBackColor = true;
            // 
            // cbFilm
            // 
            this.cbFilm.FormattingEnabled = true;
            this.cbFilm.Location = new System.Drawing.Point(235, 394);
            this.cbFilm.Name = "cbFilm";
            this.cbFilm.Size = new System.Drawing.Size(204, 24);
            this.cbFilm.TabIndex = 108;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label4.Location = new System.Drawing.Point(172, 394);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 25);
            this.label4.TabIndex = 109;
            this.label4.Text = "Film";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label5.Location = new System.Drawing.Point(161, 462);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 24);
            this.label5.TabIndex = 110;
            this.label5.Text = "Seans";
            // 
            // cbSeans
            // 
            this.cbSeans.FormattingEnabled = true;
            this.cbSeans.Items.AddRange(new object[] {
            "10:00",
            "12:30",
            "15:00",
            "18:00",
            "21:00",
            "23:00"});
            this.cbSeans.Location = new System.Drawing.Point(231, 462);
            this.cbSeans.Name = "cbSeans";
            this.cbSeans.Size = new System.Drawing.Size(207, 24);
            this.cbSeans.TabIndex = 111;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.label6.Location = new System.Drawing.Point(254, 514);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 25);
            this.label6.TabIndex = 112;
            this.label6.Text = "Bilet";
            // 
            // rbOgrenci
            // 
            this.rbOgrenci.AutoSize = true;
            this.rbOgrenci.Location = new System.Drawing.Point(337, 519);
            this.rbOgrenci.Name = "rbOgrenci";
            this.rbOgrenci.Size = new System.Drawing.Size(103, 20);
            this.rbOgrenci.TabIndex = 113;
            this.rbOgrenci.TabStop = true;
            this.rbOgrenci.Text = "Öğrenci : 15₺";
            this.rbOgrenci.UseVisualStyleBackColor = true;
            // 
            // rbTam
            // 
            this.rbTam.AutoSize = true;
            this.rbTam.Location = new System.Drawing.Point(497, 521);
            this.rbTam.Name = "rbTam";
            this.rbTam.Size = new System.Drawing.Size(84, 20);
            this.rbTam.TabIndex = 114;
            this.rbTam.TabStop = true;
            this.rbTam.Text = "Tam : 30₺";
            this.rbTam.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rderkek);
            this.panel1.Controls.Add(this.rdkadin);
            this.panel1.Location = new System.Drawing.Point(576, 456);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 39);
            this.panel1.TabIndex = 115;
            // 
            // SinemaRezervasyonProjesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1451, 661);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.rbTam);
            this.Controls.Add(this.rbOgrenci);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbSeans);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbFilm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btniptalet);
            this.Controls.Add(this.btnkaydet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblboskoltuksayisi);
            this.Controls.Add(this.koltuk35);
            this.Controls.Add(this.koltuk34);
            this.Controls.Add(this.koltuk33);
            this.Controls.Add(this.koltuk32);
            this.Controls.Add(this.koltuk31);
            this.Controls.Add(this.koltuk30);
            this.Controls.Add(this.koltuk29);
            this.Controls.Add(this.koltuk28);
            this.Controls.Add(this.koltuk27);
            this.Controls.Add(this.koltuk26);
            this.Controls.Add(this.koltuk25);
            this.Controls.Add(this.koltuk24);
            this.Controls.Add(this.koltuk23);
            this.Controls.Add(this.koltuk22);
            this.Controls.Add(this.koltuk21);
            this.Controls.Add(this.koltuk20);
            this.Controls.Add(this.koltuk19);
            this.Controls.Add(this.koltuk18);
            this.Controls.Add(this.koltuk17);
            this.Controls.Add(this.koltuk16);
            this.Controls.Add(this.koltuk15);
            this.Controls.Add(this.koltuk14);
            this.Controls.Add(this.koltuk13);
            this.Controls.Add(this.koltuk12);
            this.Controls.Add(this.koltuk11);
            this.Controls.Add(this.koltuk10);
            this.Controls.Add(this.koltuk9);
            this.Controls.Add(this.koltuk8);
            this.Controls.Add(this.koltuk7);
            this.Controls.Add(this.koltuk6);
            this.Controls.Add(this.koltuk5);
            this.Controls.Add(this.koltuk4);
            this.Controls.Add(this.koltuk3);
            this.Controls.Add(this.koltuk2);
            this.Controls.Add(this.koltuk1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbletiket1);
            this.Controls.Add(this.lbldolu);
            this.Controls.Add(this.lblbos);
            this.Controls.Add(this.txtiptalkoltukno);
            this.Controls.Add(this.lbliptaledilenkoltukno);
            this.Controls.Add(this.txtkoltukno);
            this.Controls.Add(this.lblsecilenkoltukno);
            this.Controls.Add(this.txtsoyisim);
            this.Controls.Add(this.textisim);
            this.Controls.Add(this.lblsoyisim);
            this.Controls.Add(this.lblisim);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1572, 726);
            this.MinimumSize = new System.Drawing.Size(1421, 600);
            this.Name = "SinemaRezervasyonProjesi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sinema Rezervasyon İşlemleri";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblisim;
        private System.Windows.Forms.Label lblsoyisim;
        private System.Windows.Forms.TextBox textisim;
        private System.Windows.Forms.TextBox txtsoyisim;
        private System.Windows.Forms.Label lblsecilenkoltukno;
        private System.Windows.Forms.TextBox txtkoltukno;

        private System.Windows.Forms.TextBox txtiptalkoltukno;
        private System.Windows.Forms.Label lbliptaledilenkoltukno;
        private System.Windows.Forms.Label lblbos;
        private System.Windows.Forms.Label lbletiket1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label koltuk1;
        private System.Windows.Forms.Label koltuk2;
        private System.Windows.Forms.Label koltuk3;
        private System.Windows.Forms.Label koltuk4;
        private System.Windows.Forms.Label koltuk6;
        private System.Windows.Forms.Label koltuk7;
        private System.Windows.Forms.Label koltuk8;
        private System.Windows.Forms.Label koltuk9;
        private System.Windows.Forms.Label koltuk10;
        private System.Windows.Forms.Label koltuk11;
        private System.Windows.Forms.Label koltuk12;
        private System.Windows.Forms.Label koltuk13;
        private System.Windows.Forms.Label koltuk14;
        private System.Windows.Forms.Label koltuk15;
        private System.Windows.Forms.Label koltuk16;
        private System.Windows.Forms.Label koltuk17;
        private System.Windows.Forms.Label koltuk18;
        private System.Windows.Forms.Label koltuk20;
        private System.Windows.Forms.Label koltuk21;
        private System.Windows.Forms.Label koltuk22;
        private System.Windows.Forms.Label koltuk23;
        private System.Windows.Forms.Label koltuk24;
        private System.Windows.Forms.Label koltuk25;
        private System.Windows.Forms.Label koltuk26;
        private System.Windows.Forms.Label koltuk27;
        private System.Windows.Forms.Label koltuk28;
        private System.Windows.Forms.Label koltuk29;
        private System.Windows.Forms.Label koltuk30;
        private System.Windows.Forms.Label koltuk31;
        private System.Windows.Forms.Label koltuk32;
        private System.Windows.Forms.Label koltuk33;
        private System.Windows.Forms.Label koltuk34;
        private System.Windows.Forms.Label koltuk35;
        private System.Windows.Forms.Label koltuk5;
        private System.Windows.Forms.Label koltuk19;
        private System.Windows.Forms.Label lbldolu;
        private System.Windows.Forms.Label lblboskoltuksayisi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnkaydet;
        private System.Windows.Forms.Button btniptalet;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdkadin;
        private System.Windows.Forms.RadioButton rderkek;
        private System.Windows.Forms.ComboBox cbFilm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbSeans;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rbOgrenci;
        private System.Windows.Forms.RadioButton rbTam;
        private System.Windows.Forms.Panel panel1;
    }
}

