﻿namespace Sinema_Programı
{
    partial class YoneticiPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YoneticiPaneli));
            this.txtFilmAd = new System.Windows.Forms.TextBox();
            this.txtFilmtur = new System.Windows.Forms.TextBox();
            this.txtFilmYonetmen = new System.Windows.Forms.TextBox();
            this.txtFilmOyuncu = new System.Windows.Forms.TextBox();
            this.txtFilmImdb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnFilmEkle = new System.Windows.Forms.Button();
            this.btnFilmCıkar = new System.Windows.Forms.Button();
            this.cbFilm = new System.Windows.Forms.ComboBox();
            this.cbSalonNo = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbSeans = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // txtFilmAd
            // 
            this.txtFilmAd.Location = new System.Drawing.Point(88, 87);
            this.txtFilmAd.Name = "txtFilmAd";
            this.txtFilmAd.Size = new System.Drawing.Size(100, 20);
            this.txtFilmAd.TabIndex = 43;
            // 
            // txtFilmtur
            // 
            this.txtFilmtur.Location = new System.Drawing.Point(88, 137);
            this.txtFilmtur.Name = "txtFilmtur";
            this.txtFilmtur.Size = new System.Drawing.Size(100, 20);
            this.txtFilmtur.TabIndex = 44;
            // 
            // txtFilmYonetmen
            // 
            this.txtFilmYonetmen.Location = new System.Drawing.Point(88, 189);
            this.txtFilmYonetmen.Name = "txtFilmYonetmen";
            this.txtFilmYonetmen.Size = new System.Drawing.Size(100, 20);
            this.txtFilmYonetmen.TabIndex = 46;
            // 
            // txtFilmOyuncu
            // 
            this.txtFilmOyuncu.Location = new System.Drawing.Point(88, 242);
            this.txtFilmOyuncu.Name = "txtFilmOyuncu";
            this.txtFilmOyuncu.Size = new System.Drawing.Size(100, 20);
            this.txtFilmOyuncu.TabIndex = 45;
            // 
            // txtFilmImdb
            // 
            this.txtFilmImdb.Location = new System.Drawing.Point(88, 291);
            this.txtFilmImdb.Name = "txtFilmImdb";
            this.txtFilmImdb.Size = new System.Drawing.Size(100, 20);
            this.txtFilmImdb.TabIndex = 48;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = "Film Adı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 50;
            this.label2.Text = "Film Türü";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(91, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 51;
            this.label4.Text = "Film Yönetmeni";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(91, 223);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 52;
            this.label5.Text = "Film Oyuncuları";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(88, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "Film IMDB";
            // 
            // btnFilmEkle
            // 
            this.btnFilmEkle.Location = new System.Drawing.Point(63, 361);
            this.btnFilmEkle.Name = "btnFilmEkle";
            this.btnFilmEkle.Size = new System.Drawing.Size(75, 23);
            this.btnFilmEkle.TabIndex = 54;
            this.btnFilmEkle.Text = "Film Ekle";
            this.btnFilmEkle.UseVisualStyleBackColor = true;
            this.btnFilmEkle.Click += new System.EventHandler(this.btnFilmEkle_Click);
            // 
            // btnFilmCıkar
            // 
            this.btnFilmCıkar.Location = new System.Drawing.Point(161, 361);
            this.btnFilmCıkar.Name = "btnFilmCıkar";
            this.btnFilmCıkar.Size = new System.Drawing.Size(75, 23);
            this.btnFilmCıkar.TabIndex = 55;
            this.btnFilmCıkar.Text = "Film Çıkar";
            this.btnFilmCıkar.UseVisualStyleBackColor = true;
            // 
            // cbFilm
            // 
            this.cbFilm.FormattingEnabled = true;
            this.cbFilm.Location = new System.Drawing.Point(436, 87);
            this.cbFilm.Name = "cbFilm";
            this.cbFilm.Size = new System.Drawing.Size(121, 21);
            this.cbFilm.TabIndex = 56;
            // 
            // cbSalonNo
            // 
            this.cbSalonNo.FormattingEnabled = true;
            this.cbSalonNo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cbSalonNo.Location = new System.Drawing.Point(584, 87);
            this.cbSalonNo.Name = "cbSalonNo";
            this.cbSalonNo.Size = new System.Drawing.Size(121, 21);
            this.cbSalonNo.TabIndex = 57;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(443, 174);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 58;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(518, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 65;
            this.button1.Text = "seans ekle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(440, 214);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 66;
            this.label7.Text = "Seans";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(443, 155);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 67;
            this.label8.Text = "Tarih";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(437, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 68;
            this.label9.Text = "Film Adı";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(581, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 13);
            this.label10.TabIndex = 69;
            this.label10.Text = "Salon Numarası";
            // 
            // cbSeans
            // 
            this.cbSeans.FormattingEnabled = true;
            this.cbSeans.Items.AddRange(new object[] {
            "10:00",
            "12:30",
            "15:00",
            "18:00",
            "21:00",
            "23:00"});
            this.cbSeans.Location = new System.Drawing.Point(436, 251);
            this.cbSeans.Name = "cbSeans";
            this.cbSeans.Size = new System.Drawing.Size(135, 21);
            this.cbSeans.TabIndex = 70;
            // 
            // YoneticiPaneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(733, 427);
            this.Controls.Add(this.cbSeans);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cbSalonNo);
            this.Controls.Add(this.cbFilm);
            this.Controls.Add(this.btnFilmCıkar);
            this.Controls.Add(this.btnFilmEkle);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFilmImdb);
            this.Controls.Add(this.txtFilmYonetmen);
            this.Controls.Add(this.txtFilmOyuncu);
            this.Controls.Add(this.txtFilmtur);
            this.Controls.Add(this.txtFilmAd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "YoneticiPaneli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "--";
            this.Load += new System.EventHandler(this.YoneticiPaneli_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtFilmAd;
        private System.Windows.Forms.TextBox txtFilmtur;
        private System.Windows.Forms.TextBox txtFilmYonetmen;
        private System.Windows.Forms.TextBox txtFilmOyuncu;
        private System.Windows.Forms.TextBox txtFilmImdb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnFilmEkle;
        private System.Windows.Forms.Button btnFilmCıkar;
        private System.Windows.Forms.ComboBox cbFilm;
        private System.Windows.Forms.ComboBox cbSalonNo;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbSeans;
    }
}