# Sinema Rezervasyon Otomasyonu
Veritabanı kullanılmadan geliştirdiğim bir sinema rezervasyon projesidir.




###  Ana Ekran
![1](https://user-images.githubusercontent.com/25087769/52559979-f31e2a80-2e07-11e9-8859-fc7debc815b6.PNG)


###  Yönetici Giriş Ekranı
![2](https://user-images.githubusercontent.com/25087769/52559986-f6191b00-2e07-11e9-81fb-265245f0319b.PNG)




###  Yönetici Paneli
![3](https://user-images.githubusercontent.com/25087769/52559990-f87b7500-2e07-11e9-9458-155db44ec070.PNG)



###  Kullanıcı Giriş Ekranı
![4](https://user-images.githubusercontent.com/25087769/52559997-fd402900-2e07-11e9-919e-9c586d6c1988.PNG)




###  Sinema Rezervasyon İşlemleri - 1
![5](https://user-images.githubusercontent.com/25087769/52560000-016c4680-2e08-11e9-864a-9869ed5e4a45.PNG)




###  Sinema Rezervasyon İşlemleri - 2
![6](https://user-images.githubusercontent.com/25087769/52560005-05986400-2e08-11e9-8e72-205ebd7e32d6.PNG)
